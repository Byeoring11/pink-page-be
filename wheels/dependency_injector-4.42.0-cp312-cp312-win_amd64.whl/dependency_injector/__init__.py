"""Top-level package."""

__version__ = "4.42.0"
"""Version number.

:type: str
"""
